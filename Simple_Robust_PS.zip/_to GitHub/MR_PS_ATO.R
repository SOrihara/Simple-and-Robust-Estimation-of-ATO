

rm(list=ls())
set.seed(20230605)

library(CBPS)
library(MASS)
library(twang)
library(ggplot2)


nn <- 1000000
KK <- 10000

ipwO_logi1 <- aipwO_logi1 <- brO_logi1 <- rep(0,KK)
ipwO_logi2 <- aipwO_logi2 <- brO_logi2 <- rep(0,KK)
ipwO_logi3 <- aipwO_logi3 <- brO_logi3 <- rep(0,KK)
ipwO_CBPS1 <- aipwO_CBPS1 <- brO_CBPS1 <- rep(0,KK)
ipwO_bCRT1 <- aipwO_bCRT1 <- brO_bCRT1 <- rep(0,KK)
ipwO_INT1 <- aipwO_INT1 <- brO_INT1 <- rep(0,KK)
ipwO_INT2 <- aipwO_INT2 <- brO_INT2 <- rep(0,KK)

wgt1 <- wgt2 <- matrix(0,ncol=3,nrow=KK)

ps_logi1_sum <- ps_logi2_sum <- ps_logi3_sum <- matrix(0,ncol=nn,nrow=KK)
ps_CBPS1_sum <- ps_bCRT1_sum <- matrix(0,ncol=nn,nrow=KK)
ps_INT1_sum <- ps_INT2_sum <- matrix(0,ncol=nn,nrow=KK)


ATO_func <- function(TT,XX,TTXX,ps){
  nn <- length(TT); ll <- ncol(TTXX)
  
  ####Outcome regression
  YY_coef <- glm(YY~TT+TT*TTXX+XX,family=binomial)$coef
  YY1_pred <- (1+exp(-cbind(1,1,TTXX,XX,TTXX)%*%YY_coef))^(-1)
  YY0_pred <- (1+exp(-cbind(1,0,TTXX,XX,matrix(0,ncol=ll,nrow=nn))%*%YY_coef))^(-1)
  
  ###IPW estimators for the ATO
  ipwO <- sum(TT*YY*(1-ps))/sum(TT*(1-ps))-sum((1-TT)*YY*ps)/sum((1-TT)*ps)
  
  ###AIPW estimators for the ATO
  aipwO <- sum(ps*(1-ps)*(YY1_pred-YY0_pred))/sum(ps*(1-ps))+(sum(TT*(1-ps)*(YY-YY1_pred))/sum(TT*(1-ps))-sum((1-TT)*ps*(YY-YY0_pred))/sum((1-TT)*ps))
  
  ###BR estimators for the ATO
  YY_br_coef <- glm(YY~TT+TT*TTXX+XX+c(TT*(1-ps)/sum(TT*(1-ps),na.rm=T))+c((1-TT)*ps/sum((1-TT)*ps,na.rm=T)),family=binomial)$coef
  YY1_br_pred <- (1+exp(-cbind(1,1,TTXX,XX,c((1-ps)/sum(TT*(1-ps))),0,TTXX)%*%YY_br_coef))^(-1)
  YY0_br_pred <- (1+exp(-cbind(1,0,TTXX,XX,0,c(ps/sum((1-TT)*ps)),matrix(0,ncol=ll,nrow=nn))%*%YY_br_coef))^(-1)
  
  brO <- sum(ps*(1-ps)*(YY1_br_pred-YY0_br_pred))/sum(ps*(1-ps))
  
  return(c(ipwO,aipwO,brO))
}



##Parameters for the propensity score
alpha <- c(0.4,0.8,-0.25,0.6,-0.4,-0.8,-0.5,0.7)
beta <- c(0.4,0.3,-0.36,-0.73,-0.2,0.71,-0.19,0.26)


for(kk in 1:KK){
  ##Data generating process
  ###Confounder (Refer to Wyss et al.,2014 and related manuscripts)
  XX12 <- mvrnorm(nn,rep(0,2),diag(2))
  XX2 <- cbind(rbinom(nn,1,0.5),rbinom(nn,1,0.5))
  
  pp1 <- 1/(1+exp(-0.4*(2*XX2[,1]-1)))
  pp3 <- 1/(1+exp(-0.4*(2*XX2[,2]-1)))
  #mean(pp1); mean(pp2); mean(pp3); mean(pp4)
  XX3 <- cbind(mapply(rbinom,1,1,pp1),rbinom(nn,1,0.5),mapply(rbinom,1,1,pp3),rbinom(nn,1,0.5))
  XX11 <- cbind(rnorm(nn,XX3[,2],sd=0.1),rnorm(nn,XX3[,4],sd=0.1))
  XX <- cbind(XX2[,1],XX11[,1],XX2[,2],XX11[,2],XX3[,1:2],XX12[,1],XX3[,3],XX3[,4],XX12[,2])
  #cor(XX,method="spearman")
  
  ###Propensity score (Refer to Setodji et al.,2017; Leacy and Stuart, 2014)
  ps_lin <- cbind(1,XX[,1:7])%*%alpha[1:8]   ##Option(a)
  #ps_lin <-  2.5*ps_lin  ##Option(b)
  #ps_lin <- 0.6*ps_lin+XX[,2]^2+1.2*cbind(XX[,1]*XX[,3],XX[,2]*XX[,4],XX[,4]*XX[,5],XX[,5]*XX[,6])%*%alpha[c(2,3,5,6)]   ##Option(c)
  #ps_lin <- 0.4*ps_lin+XX[,2]^2+2*cbind(XX[,1]*XX[,3],XX[,2]*XX[,4],XX[,4]*XX[,5],XX[,5]*XX[,6])%*%alpha[c(2,3,5,6)]   ##Option(d)
  #ps_lin <- ps_lin+0.5*cbind(XX[,1]*XX[,3],XX[,5]*XX[,6])%*%alpha[c(2,6)]+0.5*sin(2*XX[,2]*XX[,4])+0.5*cos(2*XX[,4]*XX[,5])-0.25*exp(2*XX[,2]*XX[,4])-0.5*XX[,2]*XX[,5]*XX[,6]   ##Option(e)
  ps_lin <- 0.5*ps_lin+cbind(XX[,1]*XX[,3],XX[,5]*XX[,6])%*%alpha[c(2,6)]+sin(2*XX[,2]*XX[,4])+cos(2*XX[,4]*XX[,5])-0.5*exp(2*XX[,2]*XX[,4])-XX[,2]*XX[,5]*XX[,6]   ##Option(f)
  
  ps <- (1+exp(-ps_lin))^(-1)
  TT <- mapply(rbinom,1,1,ps)
  #hist(ps)
  
  ###Potential outcomes (Refer to Setodji et al.,2017; Leacy and Stuart, 2014)
  ###True causal effect (risk diff.) is approximately: sum((YY1-YY0)*ps*(1-ps))/sum(ps*(1-ps)) = 
  ###Option(a): 0.153
  ###Option(b): 0.154
  ###Option(c): 0.151
  ###Option(d): 0.146
  ###Option(e): 0.141
  ###Option(f): 0.131
  prs0 <- cbind(-5,XX[,1],XX[,2],XX[,3],XX[,4],XX[,8],XX[,9],XX[,10])%*%beta+XX[,2]^2*beta[3]+cbind(0.5*XX[,1]*XX[,3],0.7*XX[,2]*XX[,4],0.5*XX[,4]*XX[,8],0.5*XX[,8]*XX[,9])%*%beta[c(2,3,5,6)]
  prs1 <- 0.2+XX[,2]+XX[,4]+prs0
  YY0 <- mapply(rbinom,1,1,(1+exp(-prs0))^(-1))
  YY1 <- mapply(rbinom,1,1,(1+exp(-prs1))^(-1))
  
  #mean(YY1) = 0.254; mean(YY0) = 0.102
  
  ###Observed outcome
  YY <- TT*YY1+(1-TT)*YY0

  
  DD_ <- data.frame(ps,as.character(TT))
  names(DD_) <- c("Propensity_score","Treatment")
  
  pdf("C:/Users/81908/Desktop/投稿論文関連/MR_PS simulation/_to GitHub/kk_ps_hist_32.pdf",width=12,height=9)
  ggplot(data=DD_,aes(x=Propensity_score,fill=Treatment,group=Treatment,color=Treatment)) +
    geom_histogram(data=DD_,aes(y=ifelse(..group..==1,..count..,-1*..count..)),position="identity", alpha = .5,) +
    labs(y="Count") + theme_classic() + theme(text = element_text(size = 24))
  dev.off()
  
  
  #plot(density(ps[TT==1]),type="l",col="red")
  #points(density(ps[TT==0]),type="l",col="blue")
  
  
  ###Dataset
  DD <- data.frame(cbind(XX,TT,YY))
  
  
  ##Analysis phase
  ###Propensity score
  ####Logistic regression
  logi1_obj <- glm(TT~V1+V2+V3+V4+V5+V6+V7,family=binomial("logit"),data=DD)
  ps_logi1_sum[kk,] <- ps_logi1 <- logi1_obj$fit
  
  logi2_obj <- glm(TT~V1+V2+V3+V4+V5+V6+V7+I(V2^2)+V1*V3+V2*V4+V4*V5+V5*V6,family=binomial("logit"),data=DD)
  ps_logi2_sum[kk,] <- ps_logi2 <- logi2_obj$fit
  
  logi3_obj <- glm(TT~V1+V2+V3+V4+V5+V6+V7+I(V2^2)+I(V4^2)+I(V7^2)+V1*V2+V1*V3+V1*V4+V1*V5+V1*V6+V1*V7+V2*V3+V2*V4+V2*V5+V2*V6+V2*V7
                   +V3*V4+V3*V5+V3*V6+V3*V7+V4*V5+V4*V6+V4*V7+V5*V6+V5*V7+V6*V7,family=binomial("logit"),data=DD)
  ps_logi3_sum[kk,] <- ps_logi3 <- logi3_obj$fit
  
  ###Proposed strategies
  ww1 <- exp(-AIC(logi1_obj)/2)+exp(-AIC(logi2_obj)/2)+exp(-AIC(logi3_obj)/2)
  wgt1[kk,] <- c(exp(-AIC(logi1_obj)/2)/ww1,exp(-AIC(logi2_obj)/2)/ww1,exp(-AIC(logi3_obj)/2)/ww1)
  ps_INT1_sum[kk,] <- ps_int1 <- (exp(-AIC(logi1_obj)/2)/ww1)*logi1_obj$fit+(exp(-AIC(logi2_obj)/2)/ww1)*logi2_obj$fit+(exp(-AIC(logi3_obj)/2)/ww1)*logi3_obj$fit
  
  ww2 <- exp(-BIC(logi1_obj)/2)+exp(-BIC(logi2_obj)/2)+exp(-BIC(logi3_obj)/2)
  wgt2[kk,] <- c(exp(-BIC(logi1_obj)/2)/ww2,exp(-BIC(logi2_obj)/2)/ww2,exp(-BIC(logi3_obj)/2)/ww2)
  ps_INT2_sum[kk,] <- ps_int2 <- (exp(-BIC(logi1_obj)/2)/ww2)*logi1_obj$fit+(exp(-BIC(logi2_obj)/2)/ww2)*logi2_obj$fit+(exp(-BIC(logi3_obj)/2)/ww2)*logi3_obj$fit
  
  
  ####CBPS
  CBPS1_obj <- CBPS(TT~V1+V2+V3+V4+V5+V6+V7+I(V2^2)+I(V4^2)+I(V7^2),ATT=0,data=DD)
  ps_CBPS1_sum[kk,] <- ps_CBPS1 <- CBPS1_obj$fit
  
  
  ###bCART	
  bCRT1_obj <- ps(TT~V1+V2+V3+V4+V5+V6+V7,data=DD,stop.method="ks.mean",verbose=F)
  ps_bCRT1_sum[kk,] <- ps_bCRT1 <- as.matrix(bCRT1_obj$ps)
  
  
  TT <- c(DD[,11]); YY <- c(DD[,12])
  XX_ <- as.matrix(cbind(DD[,c(1,3,8,9,10)],DD[,2]^2,DD[,1]*DD[,3],DD[,2]*DD[,4],DD[,4]*DD[,8],DD[,8]*DD[,9]))
  TTXX <- as.matrix(DD[,c(2,4)])
  #XX_ <- as.matrix(cbind(DD[,c(1,3,4)]))
  #TTXX <- as.matrix(DD[,2])
　　
  ATO_logi1 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_logi1)
  ATO_logi2 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_logi2)
  ATO_logi3 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_logi3)
  ATO_CBPS1 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_CBPS1)
  ATO_bCRT1 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_bCRT1)
  ATO_INT1 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_int1)
  ATO_INT2 <- ATO_func(TT=TT,XX=XX_,TTXX=TTXX,ps=ps_int2)
  
  ipwO_logi1[kk] <- ATO_logi1[1]; aipwO_logi1[kk] <- ATO_logi1[2]; brO_logi1[kk] <- ATO_logi1[3]
  ipwO_logi2[kk] <- ATO_logi2[1]; aipwO_logi2[kk] <- ATO_logi2[2]; brO_logi2[kk] <- ATO_logi2[3]
  ipwO_logi3[kk] <- ATO_logi3[1]; aipwO_logi3[kk] <- ATO_logi3[2]; brO_logi3[kk] <- ATO_logi3[3]
  ipwO_CBPS1[kk] <- ATO_CBPS1[1]; aipwO_CBPS1[kk] <- ATO_CBPS1[2]; brO_CBPS1[kk] <- ATO_CBPS1[3]
  ipwO_bCRT1[kk] <- ATO_bCRT1[1]; aipwO_bCRT1[kk] <- ATO_bCRT1[2]; brO_bCRT1[kk] <- ATO_bCRT1[3]
  ipwO_INT1[kk] <- ATO_INT1[1]; aipwO_INT1[kk] <- ATO_INT1[2]; brO_INT1[kk] <- ATO_INT1[3]
  ipwO_INT2[kk] <- ATO_INT2[1]; aipwO_INT2[kk] <- ATO_INT2[2]; brO_INT2[kk] <- ATO_INT2[3]
  
  if(kk%%20==0) print(kk)
}


true = 0.132

kekka <- cbind(ipwO_logi1,aipwO_logi1,brO_logi1,ipwO_logi2,aipwO_logi2,brO_logi2,ipwO_logi3,aipwO_logi3,brO_logi3,
               ipwO_CBPS1,aipwO_CBPS1,brO_CBPS1,ipwO_bCRT1,aipwO_bCRT1,brO_bCRT1,
               ipwO_INT1,aipwO_INT1,brO_INT1,ipwO_INT2,aipwO_INT2,brO_INT2)

summary(kekka)
#apply(kekka,2,sd,na.rm=T)
#apply(kekka-true,2,mean,na.rm=T)
100*abs((apply((kekka-true)/true,2,mean,na.rm=T)))
#abs(100*abs((apply((kekka-true)/true,2,mean,na.rm=T)))-100)
sqrt(apply((kekka-true)^2,2,mean,na.rm=T))

#boxplot(kekka,las=3,ylim=c(-1,1)); abline(h=true,col="red",lty=2,lwd=3)


#summary(wgt1)
#summary(wgt2)
wgt <- cbind(wgt1,wgt2)


#write.csv(kekka,"C:/Users/Taguri/Desktop/Orihara/PS_MR/kekka_ATO_a_n150_K10000",row.names=F)
write.csv(kekka,"/Users/taguri/Desktop/_anl/kekka_ATO_f_n150_K10000",row.names=F)
write.csv(wgt,"/Users/taguri/Desktop/_anl/wgt_f_n150_K10000",row.names=F)




